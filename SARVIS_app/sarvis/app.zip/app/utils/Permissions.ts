import { Platform, PermissionsAndroid, Alert, NativeModules } from 'react-native';

const { AccessibilityModule, YoutubeControlModule } = NativeModules;

/**
 * 앱 최초 실행 시 모든 권한 요청
 */
export async function requestAllPermissions(): Promise<void> {
  if (Platform.OS !== 'android') {
    console.log('Android 전용 기능입니다.');
    return;
  }

  try {
    // 1. 카메라, 마이크 권한 요청
    await requestCameraAndMicPermissions();
    
    // 2. Android 13 이상: 알림 권한 요청
    if (Platform.Version >= 33) {
      await requestNotificationPermission();
    }

    // 3. 접근성 서비스 권한 안내
    await showAccessibilityPermissionDialog();

  } catch (error) {
    console.error('권한 요청 중 오류:', error);
  }
}

/**
 * 카메라 및 마이크 권한 요청
 */
export async function requestCameraAndMicPermissions(): Promise<boolean> {
  try {
    const granted = await PermissionsAndroid.requestMultiple([
      PermissionsAndroid.PERMISSIONS.CAMERA,
      PermissionsAndroid.PERMISSIONS.RECORD_AUDIO,
    ]);

    const cameraGranted = granted['android.permission.CAMERA'] === PermissionsAndroid.RESULTS.GRANTED;
    const micGranted = granted['android.permission.RECORD_AUDIO'] === PermissionsAndroid.RESULTS.GRANTED;

    if (!cameraGranted) {
      console.warn('카메라 권한이 거부되었습니다.');
    }
    if (!micGranted) {
      console.warn('마이크 권한이 거부되었습니다.');
    }

    return cameraGranted && micGranted;
  } catch (error) {
    console.error('카메라/마이크 권한 요청 실패:', error);
    return false;
  }
}

/**
 * 알림 권한 요청 (Android 13+)
 */
export async function requestNotificationPermission(): Promise<boolean> {
  try {
    const granted = await PermissionsAndroid.request(
      PermissionsAndroid.PERMISSIONS.POST_NOTIFICATIONS
    );
    
    const isGranted = granted === PermissionsAndroid.RESULTS.GRANTED;
    if (!isGranted) {
      console.warn('알림 권한이 거부되었습니다.');
    }
    
    return isGranted;
  } catch (error) {
    console.error('알림 권한 요청 실패:', error);
    return false;
  }
}

/**
 * 접근성 서비스 권한 안내 팝업
 */
export async function showAccessibilityPermissionDialog(): Promise<void> {
  return new Promise((resolve) => {
    Alert.alert(
      '유튜브 조작을 위해 접근성 권한이 필요합니다.',
      'SARVIS 앱이 유튜브와 같은 다른 앱을 제어하려면 시스템 설정에서 접근성 권한을 허용해야 합니다.',
      [
        {
          text: '취소',
          style: 'cancel',
          onPress: () => resolve(),
        },
        {
          text: '설정하러 가기',
          onPress: async () => {
            try {
              await AccessibilityModule.openAccessibilitySettings();
            } catch (error) {
              console.error('접근성 설정 열기 실패:', error);
            }
            resolve();
          },
        },
      ]
    );
  });
}

/**
 * 접근성 서비스 활성화 여부 확인
 */
export async function checkAccessibilityPermission(): Promise<boolean> {
  try {
    const isEnabled = await AccessibilityModule.isAccessibilityServiceEnabled();
    return isEnabled;
  } catch (error) {
    console.error('접근성 권한 확인 실패:', error);
    return false;
  }
}

/**
 * 카메라 권한 확인
 */
export async function checkCameraPermission(): Promise<boolean> {
  try {
    const granted = await PermissionsAndroid.check(PermissionsAndroid.PERMISSIONS.CAMERA);
    return granted;
  } catch (error) {
    console.error('카메라 권한 확인 실패:', error);
    return false;
  }
}

/**
 * 마이크 권한 확인
 */
export async function checkMicPermission(): Promise<boolean> {
  try {
    const granted = await PermissionsAndroid.check(PermissionsAndroid.PERMISSIONS.RECORD_AUDIO);
    return granted;
  } catch (error) {
    console.error('마이크 권한 확인 실패:', error);
    return false;
  }
}

/**
 * 유튜브 제어 함수들
 */
export const YoutubeControl = {
  rewind: async (): Promise<void> => {
    try {
      await YoutubeControlModule.rewind();
    } catch (error) {
      console.error('유튜브 뒤로 감기 실패:', error);
    }
  },
  
  forward: async (): Promise<void> => {
    try {
      await YoutubeControlModule.forward();
    } catch (error) {
      console.error('유튜브 앞으로 감기 실패:', error);
    }
  },
  
  togglePlay: async (): Promise<void> => {
    try {
      await YoutubeControlModule.togglePlay();
    } catch (error) {
      console.error('유튜브 재생/정지 실패:', error);
    }
  },
  
  volumeUp: async (): Promise<void> => {
    try {
      await YoutubeControlModule.volumeUp();
    } catch (error) {
      console.error('유튜브 볼륨 올리기 실패:', error);
    }
  },
  
  volumeDown: async (): Promise<void> => {
    try {
      await YoutubeControlModule.volumeDown();
    } catch (error) {
      console.error('유튜브 볼륨 내리기 실패:', error);
    }
  },
  
  search: async (searchTerm: string): Promise<void> => {
    try {
      await YoutubeControlModule.search(searchTerm);
    } catch (error) {
      console.error('유튜브 검색 실패:', error);
    }
  },
  
  selectResult: async (position: number): Promise<void> => {
    try {
      await YoutubeControlModule.selectResult(position);
    } catch (error) {
      console.error('유튜브 검색 결과 선택 실패:', error);
    }
  },
};