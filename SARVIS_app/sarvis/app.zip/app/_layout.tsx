import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import 'react-native-reanimated';

import { AuthProvider } from '@/providers/auth-provider';
import { ConnectivityProvider } from '@/providers/connectivity-provider';
import { ConnectivityOverlay } from '@/components/sarvis/connectivity-overlay';

export const unstable_settings = {
  anchor: '(tabs)',
};

export default function RootLayout() {
  return (
    <AuthProvider>
      <ConnectivityProvider>
        <Stack>
          <Stack.Screen name="(auth)" options={{ headerShown: false }} />
          <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
        </Stack>
        <StatusBar style="auto" />
        <ConnectivityOverlay />
      </ConnectivityProvider>
    </AuthProvider>
  );
}
