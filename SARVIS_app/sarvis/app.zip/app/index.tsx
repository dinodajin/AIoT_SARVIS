import React, { useState, useEffect } from 'react';
import { StyleSheet, Text, View, Platform, Linking, ActivityIndicator, StatusBar } from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import NetInfo from '@react-native-community/netinfo';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { SarvisTheme } from '@/constants/sarvis-theme';
import { SarvisButton } from '@/components/sarvis/sarvis-button';
import { SarvisLogo } from '@/components/sarvis/sarvis-logo';

export default function WifiConnectScreen() {
    const router = useRouter();
    const [isChecking, setIsChecking] = useState(true);
    const [isConnected, setIsConnected] = useState(false);
    const [ssid, setSsid] = useState<string | null>(null);

    useEffect(() => {
        // 네트워크 상태 구독
        const unsubscribe = NetInfo.addEventListener(state => {
            const connected = !!state.isConnected && state.type === 'wifi';
            setIsConnected(connected);
            setIsChecking(false);

            // Wi-Fi 연결 시 SSID 확인 (Android만 지원)
            if (connected && state.type === 'wifi') {
                const details = state.details as any;
                if (details?.ssid) {
                    setSsid(details.ssid);
                }

                // SARVIS-Wifi에 연결되면 로그인 화면으로 이동
                if (details?.ssid?.includes('SARVIS') || details?.ssid?.includes('sarvis')) {
                    router.replace('/(auth)/login');
                }
            }
        });

        // 컴포넌트 언마운트 시 구독 해제
        return () => unsubscribe();
    }, []);

    // Wi-Fi 설정으로 이동
    const handleOpenWifiSettings = async () => {
        try {
            if (Platform.OS === 'android') {
                await Linking.sendIntent('android.settings.WIFI_SETTINGS');
            } else {
                const wifiSettingsUrl = 'App-Prefs:WIFI';
                const canOpen = await Linking.canOpenURL(wifiSettingsUrl);
                if (canOpen) {
                    await Linking.openURL(wifiSettingsUrl);
                } else {
                    await Linking.openURL('app-settings:');
                }
            }
        } catch (error) {
            console.error('Wi-Fi 설정 이동 실패:', error);
        }
    };

    // 연결 확인 후 수동으로 진행
    const handleManualContinue = () => {
        router.replace('/(auth)/login');
    };

    if (isChecking) {
        return (
            <SafeAreaView style={styles.container}>
                <StatusBar barStyle="dark-content" backgroundColor="white" />
                <View style={styles.loadingContainer}>
                    <ActivityIndicator size="large" color={SarvisTheme.colors.primary} />
                    <Text style={styles.loadingText}>서버와 통신하는 중...</Text>
                </View>
            </SafeAreaView>
        );
    }

    return (
        <SafeAreaView style={styles.container}>
            <StatusBar barStyle="dark-content" backgroundColor="white" />

            <View style={styles.content}>
                {/* 로고 */}
                <View style={styles.logoContainer}>
                    <SarvisLogo />
                </View>

                {/* 상태 카드 */}
                <View style={styles.card}>
                    <Text style={styles.title}>Wi-Fi 연결 안내</Text>

                    <View style={styles.noticeBox}>
                        <View style={styles.noticeIconWrapper}>
                            <MaterialIcons name="info" size={20} color={SarvisTheme.colors.primary} />
                        </View>
                        <Text style={styles.noticeText}>
                            <Text style={styles.noticeBold}>로봇의 전원을 먼저 켜주세요!</Text>{"\n"}
                            <Text style={styles.noticeSubText}>로봇이 켜지면 자동으로 Wi-Fi가 활성화됩니다.</Text>
                        </Text>
                    </View>

                    {isConnected ? (
                        <>
                            <View style={styles.instructionBox}>
                                <View style={styles.stepRow}>
                                    <View style={styles.stepNumber}>
                                        <Text style={styles.stepNumberText}>1</Text>
                                    </View>
                                    <Text style={styles.stepText}>
                                        Wi-Fi 설정으로 이동합니다.
                                    </Text>
                                </View>
                                <View style={styles.stepRow}>
                                    <View style={styles.stepNumber}>
                                        <Text style={styles.stepNumberText}>2</Text>
                                    </View>
                                    <Text style={styles.stepText}>
                                        목록에서 <Text style={styles.boldText}>"SARVIS-Wifi"</Text>를 선택하세요.
                                    </Text>
                                </View>
                                <View style={styles.stepRow}>
                                    <View style={styles.stepNumber}>
                                        <Text style={styles.stepNumberText}>3</Text>
                                    </View>
                                    <Text style={styles.stepText}>
                                        연결이 완료되면 앱으로 돌아오세요.
                                    </Text>
                                </View>
                            </View>

                            <View style={styles.buttonStack}>
                                <SarvisButton
                                    title="Wi-Fi 설정으로 이동"
                                    variant="primary"
                                    onPress={handleOpenWifiSettings}
                                    style={styles.mainButton}
                                />
                                <SarvisButton
                                    title="연결 완료"
                                    variant="outline"
                                    onPress={handleManualContinue}
                                    style={styles.subButton}
                                />
                            </View>
                        </>
                    ) : (
                        <>
                            <View style={styles.instructionBox}>
                                <View style={styles.stepRow}>
                                    <View style={styles.stepNumber}>
                                        <Text style={styles.stepNumberText}>1</Text>
                                    </View>
                                    <Text style={styles.stepText}>
                                        Wi-Fi 설정으로 이동합니다.
                                    </Text>
                                </View>
                                <View style={styles.stepRow}>
                                    <View style={styles.stepNumber}>
                                        <Text style={styles.stepNumberText}>2</Text>
                                    </View>
                                    <Text style={styles.stepText}>
                                        목록에서 <Text style={styles.boldText}>"SARVIS-Wifi"</Text>를 선택하세요.
                                    </Text>
                                </View>
                                <View style={styles.stepRow}>
                                    <View style={styles.stepNumber}>
                                        <Text style={styles.stepNumberText}>3</Text>
                                    </View>
                                    <Text style={styles.stepText}>
                                        연결이 완료되면 앱으로 돌아오세요.
                                    </Text>
                                </View>
                            </View>

                            <View style={styles.buttonStack}>
                                <SarvisButton
                                    title="Wi-Fi 설정으로 이동"
                                    variant="primary"
                                    onPress={handleOpenWifiSettings}
                                    style={styles.mainButton}
                                />
                                <SarvisButton
                                    title="연결 완료"
                                    variant="outline"
                                    onPress={handleManualContinue}
                                    style={styles.subButton}
                                />
                            </View>
                        </>
                    )}
                </View>

                {/* 하단 링크 */}
                <Text style={styles.footerText}>
                    연결 문제가 있으신가요?{' '}
                    <Text style={styles.linkText} onPress={handleManualContinue}>
                        건너뛰기
                    </Text>
                </Text>
            </View>
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: SarvisTheme.colors.bg,
    },
    loadingContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        gap: 16,
    },
    loadingText: {
        fontSize: 15,
        color: SarvisTheme.colors.textLight,
        marginTop: 16,
        fontWeight: '700',
        width: 150,
        textAlign: 'center',
    },
    content: {
        flex: 1,
        padding: 24,
        justifyContent: 'center',
    },
    logoContainer: {
        alignItems: 'center',
        marginBottom: 20,
    },
    card: {
        backgroundColor: '#ffffff',
        borderRadius: 30,
        padding: 28,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 10 },
        shadowOpacity: 0.08,
        shadowRadius: 20,
        elevation: 8,
    },
    title: {
        fontSize: 22,
        fontWeight: '900',
        color: SarvisTheme.colors.text,
        marginBottom: 20,
        textAlign: 'center',
    },
    noticeBox: {
        backgroundColor: '#FEF3C7',
        borderRadius: 16,
        padding: 16,
        marginBottom: 20,
        flexDirection: 'row',
        alignItems: 'flex-start',
        gap: 12,
        borderWidth: 1,
        borderColor: '#FDE68A',
    },
    noticeIconWrapper: {
        width: 28,
        height: 28,
        borderRadius: 14,
        backgroundColor: '#FFFFFF',
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 2,
    },
    noticeText: {
        flex: 1,
        fontSize: 13,
        color: '#92400E',
        lineHeight: 20,
        fontWeight: '600',
    },
    noticeBold: {
        fontWeight: '800',
        color: '#78350F',
    },
    noticeSubText: {
        fontSize: 11,
        fontWeight: '500',
    },
    instructionBox: {
        backgroundColor: '#F8FAFC',
        borderRadius: 20,
        padding: 20,
        marginBottom: 24,
        gap: 14,
    },
    stepRow: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 14,
    },
    stepNumber: {
        width: 24,
        height: 24,
        borderRadius: 12,
        backgroundColor: '#E2E8F0',
        justifyContent: 'center',
        alignItems: 'center',
    },
    stepNumberText: {
        fontSize: 12,
        fontWeight: '800',
        color: '#64748B',
    },
    stepText: {
        flex: 1,
        fontSize: 14,
        color: SarvisTheme.colors.text,
        fontWeight: '600',
    },
    boldText: {
        fontWeight: '900',
        color: SarvisTheme.colors.primary,
    },
    buttonStack: {
        gap: 12,
    },
    mainButton: {
        height: 56,
        borderRadius: 16,
    },
    subButton: {
        height: 56,
        borderRadius: 16,
        borderWidth: 0,
        backgroundColor: 'transparent',
    },
    footerText: {
        marginTop: 24,
        fontSize: 14,
        color: SarvisTheme.colors.textMuted,
        textAlign: 'center',
    },
    linkText: {
        color: SarvisTheme.colors.primary,
        fontWeight: '700',
    },
});
