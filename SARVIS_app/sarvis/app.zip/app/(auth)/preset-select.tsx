import React, { useEffect, useState } from 'react';
import { Alert, ActivityIndicator, StyleSheet, Text, TouchableOpacity, View, ScrollView } from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';

import { SarvisAppHeader } from '@/components/sarvis/sarvis-app-header';
import { SarvisTheme } from '@/constants/sarvis-theme';
import { useAuth } from '@/providers/auth-provider';
import { presetAPI } from '@/api/preset';
import { Preset } from '@/api/types';

export default function PresetSelectScreen() {
  const router = useRouter();
  const { user, selectPreset } = useAuth();
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [isApplying, setIsApplying] = useState(false);
  const [presets, setPresets] = useState<Preset[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // ✅ 페이지 로드 시 프리셋 목록 조회
  useEffect(() => {
    loadPresets();
  }, []);

  const loadPresets = async () => {
    try {
      setIsLoading(true);
      const response = await presetAPI.getPresets();

      // 🔍 서버에서 실제로 온 데이터를 확인해보세요
      console.log('🔍 서버 응답 데이터:', JSON.stringify(response));

      if (response && response.presets) {
        setPresets(response.presets);
      } else {
        console.warn('⚠️ presets 필드가 없습니다.');
        setPresets([]);
      }
    } catch (error: any) {
      // 🔍 여기서 에러의 세부 내용을 출력합니다.
      console.error('❌ API 호출 실패 세부사항:', {
        message: error.message,
        status: error.response?.status,
        data: error.response?.data
      });

      Alert.alert('오류', '프리셋 목록을 불러오지 못했습니다.');
      setPresets([]);
    } finally {
      setIsLoading(false);
    }
  };

  const handlePresetSelect = async (preset: Preset) => {
    // ✅ 서버에서 받은 프리셋 ID 사용 (기본 프리셋은 0)
    const presetId = preset.preset_id ?? 0;
    setSelectedId(presetId);
    setIsApplying(true);

    try {
      console.log('✅ 프리셋 선택 시도:', preset);
      console.log('✅ 전송할 preset_id:', presetId);

      // ✅ 서버에 프리셋 선택 전송
      const response = await presetAPI.selectPreset(presetId);
      console.log('✅ 프리셋 선택 완료 (서버 전송):', response);

      // ✅ AuthContext에 선택된 프리셋 저장
      selectPreset(preset);

      // ✅ 메인 화면으로 이동 (탭 화면)
      router.replace('/(tabs)');
    } catch (error: any) {
      console.error('프리셋 선택 실패:', error);
      Alert.alert(
        '오류',
        error.response?.data?.message || error.message || '프리셋을 선택하지 못했습니다.'
      );
      setSelectedId(null);
    } finally {
      setIsApplying(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <SarvisAppHeader showBackButton={true} />

      <View style={styles.header}>
        <Text style={styles.greetingText}>
          반갑습니다, {user?.nickname}님!
        </Text>
        <Text style={styles.subtitleText}>
          사용할 프리셋을 선택해주세요.
        </Text>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>
        {isLoading ? (
          <View style={styles.centerContainer}>
            <ActivityIndicator size="large" color={SarvisTheme.colors.primary} />
            <Text style={styles.loadingText}>프리셋 목록을 불러오는 중...</Text>
          </View>
        ) : (!presets || presets.length === 0) ? (
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>저장된 프리셋이 없습니다.</Text>
            <Text style={styles.emptySubText}>
              설정에서 프리셋을 생성해주세요.
            </Text>
          </View>
        ) : (
          presets.map((preset, index) => {
            const presetId = preset.preset_id ?? 0;
            return (
              <TouchableOpacity
                key={`${preset.preset_id || 'default'}-${index}`}
                style={[
                  styles.presetCard,
                  selectedId === presetId && styles.presetCardSelected
                ]}
                onPress={() => handlePresetSelect(preset)}
                disabled={isApplying}
                activeOpacity={0.7}
              >
                <View style={styles.presetHeader}>
                  <Text style={[
                    styles.presetName,
                    selectedId === presetId && styles.presetNameSelected
                  ]}>
                    {preset.name}
                  </Text>
                  {selectedId === presetId && (
                    <Text style={styles.checkIcon}>✓</Text>
                  )}
                </View>

                <View style={styles.presetDetails}>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>Servo 1:</Text>
                    <Text style={styles.detailValue}>{preset.servo1}°</Text>
                  </View>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>Servo 2:</Text>
                    <Text style={styles.detailValue}>{preset.servo2}°</Text>
                  </View>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>Servo 3:</Text>
                    <Text style={styles.detailValue}>{preset.servo3}°</Text>
                  </View>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>Servo 4:</Text>
                    <Text style={styles.detailValue}>{preset.servo4}°</Text>
                  </View>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>Servo 5:</Text>
                    <Text style={styles.detailValue}>{preset.servo5}°</Text>
                  </View>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>Servo 6:</Text>
                    <Text style={styles.detailValue}>{preset.servo6}°</Text>
                  </View>
                  {preset.created_at && (
                    <View style={styles.detailRow}>
                      <Text style={styles.detailLabel}>생성일:</Text>
                      <Text style={styles.detailValue}>
                        {new Date(preset.created_at).toLocaleDateString()}
                      </Text>
                    </View>
                  )}
                </View>

                {isApplying && selectedId === presetId && (
                  <View style={styles.loadingOverlay}>
                    <ActivityIndicator size="small" color="white" />
                  </View>
                )}
              </TouchableOpacity>
            );
          })
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: SarvisTheme.colors.textLight,
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 24,
    backgroundColor: 'white',
  },
  greetingText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: SarvisTheme.colors.text,
    marginBottom: 8,
  },
  subtitleText: {
    fontSize: 14,
    color: SarvisTheme.colors.textLight,
  },
  scrollContent: {
    padding: 20,
  },
  emptyContainer: {
    alignItems: 'center',
    paddingVertical: 40,
  },
  emptyText: {
    fontSize: 16,
    color: SarvisTheme.colors.text,
    marginBottom: 8,
  },
  emptySubText: {
    fontSize: 14,
    color: SarvisTheme.colors.textLight,
  },
  presetCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    borderWidth: 2,
    borderColor: 'transparent',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  presetCardSelected: {
    borderColor: SarvisTheme.colors.primary,
    backgroundColor: SarvisTheme.colors.primary + '10',
  },
  presetHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  presetName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: SarvisTheme.colors.text,
    flex: 1,
  },
  presetNameSelected: {
    color: SarvisTheme.colors.primary,
  },
  checkIcon: {
    fontSize: 24,
    fontWeight: 'bold',
    color: SarvisTheme.colors.primary,
  },
  presetDetails: {
    backgroundColor: SarvisTheme.colors.bg,
    borderRadius: 12,
    padding: 12,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 4,
    borderBottomWidth: 1,
    borderBottomColor: SarvisTheme.colors.border,
  },
  detailLabel: {
    fontSize: 14,
    color: SarvisTheme.colors.textLight,
    fontWeight: '600',
    width: 60,
  },
  detailValue: {
    fontSize: 14,
    color: SarvisTheme.colors.text,
    fontWeight: '500',
  },
  loadingOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
  },
});