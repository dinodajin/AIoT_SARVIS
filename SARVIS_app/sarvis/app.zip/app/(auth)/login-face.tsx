import React, { useState, useRef, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert, Image, ActivityIndicator } from 'react-native';
import { useRouter } from 'expo-router';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../providers/auth-provider';
import { biometricAPI } from '../../api/biometric';
import { authAPI } from '../../api/auth';
import { presetAPI } from '../../api/preset';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

export default function LoginFaceScreen() {
  const router = useRouter();
  const { signIn, setConnectionUuid } = useAuth();
  const insets = useSafeAreaInsets();

  const [permission, requestPermission] = useCameraPermissions();
  const cameraRef = useRef<CameraView>(null);

  const [isCapturing, setIsCapturing] = useState(false);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);

  // 카메라 권한 요청
  useEffect(() => {
    if (permission && !permission.granted) {
      requestPermission();
    }
  }, [permission]);

  const handleCapture = async () => {
    console.log('📸 촬영 버튼 눌림');
    if (!cameraRef.current) {
      console.log('❌ 카메라 ref 없음');
      return;
    }

    try {
      if (isCapturing) return;
      setIsCapturing(true);

      console.log('📸 사진 촬영 시도...');
      const photo = await cameraRef.current.takePictureAsync({
        quality: 0.8,
        base64: false, // URI만 필요함
      });
      console.log('📸 사진 촬영 완료:', photo?.uri);

      if (photo?.uri) {
        setCapturedImage(photo.uri);
        await attemptFaceLogin(photo.uri);
      }
    } catch (error) {
      console.error('❌ 카메라 촬영 실패:', error);
      Alert.alert('오류', '사진 촬영에 실패했습니다.');
      setIsCapturing(false);
      setCapturedImage(null);
    }
  };


  const attemptFaceLogin = async (imageUri: string) => {
    try {
      console.log('🚀 얼굴 로그인 시도...');
      const result = await biometricAPI.loginFace(imageUri);
      console.log('✅ 얼굴 로그인 응답:', result);

      const response = result as any; // 타입 캐스팅 (BiometricUploadResponse에는 tokens가 없을 수 있음)

      if (response && response.success) {
        // 1. 토큰 추출 (중첩 객체 처리)
        let accessToken = '';
        let refreshToken = '';

        if (response.tokens) {
          accessToken = response.tokens.access;
          refreshToken = response.tokens.refresh;
        } else if (response.access_token && typeof response.access_token === 'object') {
          // Jetson 응답이 access_token을 객체로 주는 경우
          accessToken = response.access_token.access;
          refreshToken = response.access_token.refresh;
        } else if (typeof response.access_token === 'string') {
          // 문자열인 경우 (단순 토큰)
          accessToken = response.access_token;
        }

        if (!accessToken) throw new Error('토큰이 없습니다.');

        // 2. 토큰을 임시로 스토리지에 저장 (authAPI.getProfile 호출을 위해 필요)
        const { default: AsyncStorage } = await import('@react-native-async-storage/async-storage');
        await AsyncStorage.setItem('@sarvis_access_token', accessToken);

        // 3. 내 정보(프로필) 조회
        console.log('👤 사용자 정보 조회 중...');
        const profileResponse = await authAPI.getProfile();
        console.log('✅ 사용자 정보 조회 성공:', profileResponse);


        const user = (profileResponse as any).user;

        if (!user) {
          throw new Error('사용자 정보를 불러올 수 없습니다.');
        }

        const userData = user;

        // 4. 로그인 처리 (정보 합치기)
        await signIn({
          uid: response.uid,
          access_token: refreshToken ? { access: accessToken, refresh: refreshToken } : accessToken,
          // refreshToken이 있으면 객체, 없으면 문자열 (signIn 처리 로직에 따라 다름, 
          // 하지만 auth-provider에서 access_token을 객체로도 파싱하게 수정했으므로 객체 추천)
          // 여기서는 access_token 필드에 객체를 넣거나, 기존 auth-provider 수정을 고려해서 맞춰야 함.
          // auth-provider.tsx:149를 보면 loginResponse.access_token이 객체인 경우와 loginResponse.tokens인 경우를 처리함.
          // 우리는 signIn의 인자로 넘길 때 loginResponse 형태를 모방해야 함.

          user_id: userData.user_id, // 프로필 응답 필드명 확인 필요 (types.ts: user_id)
          nickname: userData.nickname,
          email: userData.email,
          // user_type은 UserProfile에 없으므로 response에서 가져오거나 기본값
          user_type: response.user_type || 'user',
          face_vectors: undefined, // 프로필에 없으면 undefined, 필요시 재조회
          connection_uuid: response.connection_uuid,
          session_id: response.session_id,
          session_started_at: response.session_started_at,
        } as any); // signIn 인자 타입 맞추기 위해 캐스팅


        // 5. 프리셋 목록 확인 (Jetson 응답에 has_presets가 없을 수 있으므로 직접 조회)
        let hasPresets = false;
        try {
          // connection_uuid가 있으면 해당 기기의 프리셋을 조회할 수도 있지만, 일단 전체 조회
          const presetRes = await presetAPI.getPresets();
          if (presetRes.presets && presetRes.presets.length > 0) {
            hasPresets = true;
          }
        } catch (e) {
          console.warn('⚠️ 프리셋 조회 실패 (로그인은 성공):', e);
        }

        Alert.alert('성공', `${userData.nickname}님 환영합니다!`, [
          {
            text: '확인',
            onPress: () => {
              if (hasPresets) {
                router.replace('/(auth)/preset-select');
              } else {
                router.replace('/(tabs)');
              }
            }
          }
        ]);
      } else {
        throw new Error(response.message || '얼굴을 인식하지 못했습니다.');
      }

    } catch (error: any) {
      console.error('❌ 얼굴 로그인 실패:', error);
      Alert.alert(
        '로그인 실패',
        error.message || '얼굴 인식에 실패했습니다. 다시 시도해주세요.',
        [{
          text: '확인', onPress: () => {
            setCapturedImage(null);
            setIsCapturing(false);
          }
        }]
      );
    }
  };

  if (!permission) {
    // 권한 상태 로딩 중
    return <View style={styles.container} />;
  }

  if (!permission.granted) {
    return (
      <View style={styles.container}>
        <Text style={styles.message}>카메라 권한이 필요합니다.</Text>
        <TouchableOpacity onPress={requestPermission} style={styles.button}>
          <Text style={styles.buttonText}>권한 요청</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={[styles.header, { paddingTop: insets.top + 20 }]}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <Ionicons name="arrow-back" size={24} color="#333" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>얼굴로 로그인</Text>
        <View style={{ width: 40 }} />
      </View>

      <View style={styles.content}>
        <Text style={styles.guideText}>
          {isCapturing ? '인식 중입니다...' : '정면을 바라보고\n촬영 버튼을 눌러주세요'}
        </Text>

        <View style={styles.cameraContainer}>
          {capturedImage ? (
            <Image source={{ uri: capturedImage }} style={styles.camera} />
          ) : (
            <CameraView
              ref={cameraRef}
              style={styles.camera}
              facing="front"
            />
          )}
          {isCapturing && (
            <View style={styles.loadingOverlay}>
              <ActivityIndicator size="large" color="#ffffff" />
              <Text style={styles.loadingText}>로그인 중...</Text>
            </View>
          )}
        </View>

        <TouchableOpacity
          style={[styles.captureButton, isCapturing && styles.disabledButton]}
          onPress={handleCapture}
          disabled={isCapturing}
        >
          <Ionicons name="camera" size={32} color="#fff" />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.subButton}
          onPress={() => router.push('/(auth)/login-id')}
          disabled={isCapturing}
        >
          <Text style={styles.subButtonText}>아이디로 로그인</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  backButton: {
    padding: 8,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  content: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 20,
  },
  message: {
    textAlign: 'center',
    paddingBottom: 10,
    fontSize: 16,
    color: '#666',
  },
  guideText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
    marginBottom: 40,
    lineHeight: 30,
  },
  cameraContainer: {
    width: 280,
    height: 280,
    borderRadius: 140,
    overflow: 'hidden',
    marginBottom: 40,
    backgroundColor: '#f0f0f0',
    borderWidth: 2,
    borderColor: '#E5E5E5',
    position: 'relative',
  },
  camera: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  loadingOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: '#fff',
    marginTop: 10,
    fontSize: 16,
    fontWeight: '600',
  },
  button: {
    padding: 15,
    backgroundColor: '#2196F3',
    borderRadius: 8,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  captureButton: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: '#007AFF',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 4.65,
    elevation: 8,
  },
  disabledButton: {
    backgroundColor: '#ccc',
  },
  subButton: {
    padding: 15,
  },
  subButtonText: {
    color: '#666',
    fontSize: 15,
  },
});