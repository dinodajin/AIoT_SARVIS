import React from 'react';
import { StyleSheet, Text, View, Alert } from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';

import { SarvisButton } from '@/components/sarvis/sarvis-button';
import { SarvisFooter } from '@/components/sarvis/sarvis-footer';
import { SarvisLogo } from '@/components/sarvis/sarvis-logo';
import { SarvisTheme } from '@/constants/sarvis-theme';

/**
 * 얼굴 등록 완료 화면
 * face-capture.tsx에서 얼굴 촬영 완료 후 이동하는 화면
 */
export default function FaceRegisterScreen() {
  const router = useRouter();
  const params = useLocalSearchParams<{ uid?: string; loginId?: string; nickname?: string }>();

  const handleContinue = () => {
    console.log('👆 [FaceRegister] 목소리 등록 버튼 클릭');
    console.log('📦 [FaceRegister] 전달할 파라미터:', params);

    // 음성 등록 화면으로 이동
    router.push({
      pathname: '/(auth)/voice-register',
      params: {
        uid: String(params.uid || ''),
        loginId: String(params.loginId || ''),
        nickname: String(params.nickname || '')
      },
    } as any);
  };

  const handleSkip = () => {
    Alert.alert(
      '회원가입 완료',
      '회원가입이 완료되었습니다. (음성 등록 건너뜀)\n로그인해주세요.',
      [
        {
          text: '확인',
          onPress: () => {
            router.replace({ pathname: '/(auth)/login' } as any);
          },
        },
      ]
    );
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        <View style={styles.content}>
          <SarvisLogo subtitle="얼굴 등록 완료" />

          <View style={styles.successContainer}>
            <View style={styles.successIcon}>
              <MaterialIcons name="check-circle" size={80} color={SarvisTheme.colors.success} />
            </View>
            <Text style={styles.successTitle}>얼굴 등록이 완료되었습니다!</Text>
            <Text style={styles.successText}>
              얼굴 인식으로 빠르게 로그인할 수 있습니다.{'\n'}
              이제 목소리를 등록해주세요.
            </Text>
          </View>

          <View style={styles.buttonContainer}>
            <SarvisButton
              title="목소리 등록하기"
              variant="primary"
              onPress={handleContinue}
            />
            <SarvisButton
              title="나중에 하기"
              variant="outline"
              onPress={handleSkip}
            />
          </View>
        </View>

        <SarvisFooter />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
    justifyContent: 'space-between',
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 20,
  },
  successContainer: {
    alignItems: 'center',
    marginVertical: 40,
  },
  successIcon: {
    marginBottom: 20,
  },
  successTitle: {
    fontSize: 22,
    fontWeight: '800',
    color: SarvisTheme.colors.text,
    textAlign: 'center',
    marginBottom: 12,
  },
  successText: {
    fontSize: 15,
    color: SarvisTheme.colors.textMuted,
    textAlign: 'center',
    lineHeight: 22,
  },
  buttonContainer: {
    marginTop: 20,
  },
});