// api/websocket.ts

import {
  HeartbeatMessage,
  HeartbeatAckMessage,
  ConnectionEstablishedMessage,
  VoiceCommandMessage,
  WebSocketMessage,
} from './types';
import { API_CONFIG } from '../constants/config';

/**
 * WebSocket 연결 상태
 */
export enum WebSocketState {
  CONNECTING = 'connecting',
  CONNECTED = 'connected',
  DISCONNECTED = 'disconnected',
  ERROR = 'error',
}

/**
 * WebSocket 이벤트 핸들러
 */
export interface WebSocketHandlers {
  onConnected?: (message: ConnectionEstablishedMessage) => void;
  onHeartbeatAck?: (message: HeartbeatAckMessage) => void;
  onVoiceCommand?: (message: VoiceCommandMessage) => void;
  onError?: (error: Error) => void;
  onDisconnected?: () => void;
}

/**
 * WebSocket 하트비트 매니저
 * 
 * 기능:
 * - WebSocket 연결 관리
 * - 30초마다 하트비트 전송
 * - 연결 상태 모니터링
 * - 자동 재연결 (선택적)
 */
export class WebSocketHeartbeatManager {
  private ws: WebSocket | null = null;
  private connectionUuid: string | null = null;
  private heartbeatInterval: ReturnType<typeof setInterval> | null = null;
  private heartbeatTimeout: ReturnType<typeof setTimeout> | null = null;
  private state: WebSocketState = WebSocketState.DISCONNECTED;
  private handlers: WebSocketHandlers = {};
  private reconnectAttempts = 0;
  private maxReconnectAttempts = 3;

  /**
   * WebSocket 연결 시작
   * @param connectionUuid 연결 UUID
   * @param handlers 이벤트 핸들러
   */
  connect(connectionUuid: string, handlers: WebSocketHandlers = {}): void {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      console.log('⚠️ WebSocket이 이미 연결되어 있습니다.');
      return;
    }

    this.connectionUuid = connectionUuid;
    this.handlers = handlers;
    this.state = WebSocketState.CONNECTING;

    // WebSocket URL 생성
    // 주의: React Native에서는 ws://가 아닌 ws://를 사용해야 함
    const wsUrl = `ws://${API_CONFIG.EC2_URL.replace('http://', '').replace('https://', '')}/ws/app/${connectionUuid}/`;
    console.log('🔌 WebSocket 연결 시도:', wsUrl);

    try {
      this.ws = new WebSocket(wsUrl);

      // 연결 성공
      this.ws.onopen = () => {
        console.log('✅ WebSocket 연결 성공');
        this.state = WebSocketState.CONNECTED;
        this.reconnectAttempts = 0;
        this.startHeartbeat();
      };

      // 메시지 수신
      this.ws.onmessage = (event) => {
        try {
          const message: WebSocketMessage = JSON.parse(event.data);
          console.log('📨 WebSocket 메시지 수신:', message);

          // 메시지 타입별 핸들러 호출
          switch (message.type) {
            case 'connection_established':
              this.handlers.onConnected?.(message as ConnectionEstablishedMessage);
              break;

            case 'heartbeat_ack':
              this.handlers.onHeartbeatAck?.(message as HeartbeatAckMessage);
              this.resetHeartbeatTimeout();
              break;

            case 'voice_command':
              console.log('🎤 음성 명령 수신:', (message as VoiceCommandMessage).command);
              this.handlers.onVoiceCommand?.(message as VoiceCommandMessage);
              break;

            default:
              console.log('❓ 알 수 없는 메시지 타입:', message.type);
          }
        } catch (error) {
          console.error('❌ WebSocket 메시지 파싱 에러:', error);
        }
      };

      // 에러 발생
      this.ws.onerror = (error) => {
        console.error('❌ WebSocket 에러:', error);
        this.state = WebSocketState.ERROR;
        this.handlers.onError?.(new Error('WebSocket 연결 에러'));
      };

      // 연결 종료
      this.ws.onclose = () => {
        console.log('🔌 WebSocket 연결 종료');
        this.state = WebSocketState.DISCONNECTED;
        this.stopHeartbeat();
        this.handlers.onDisconnected?.();

        // 자동 재연결 (선택적)
        if (this.reconnectAttempts < this.maxReconnectAttempts) {
          console.log(`🔄 재연결 시도 (${this.reconnectAttempts + 1}/${this.maxReconnectAttempts})`);
          this.reconnectAttempts++;
          setTimeout(() => {
            if (this.connectionUuid) {
              this.connect(this.connectionUuid, this.handlers);
            }
          }, 3000); // 3초 후 재연결
        }
      };
    } catch (error) {
      console.error('❌ WebSocket 연결 실패:', error);
      this.state = WebSocketState.ERROR;
      this.handlers.onError?.(error instanceof Error ? error : new Error('WebSocket 연결 실패'));
    }
  }

  /**
   * 하트비트 전송 시작
   * - 30초마다 하트비트 전송
   */
  private startHeartbeat(): void {
    // 30초마다 하트비트 전송
    this.heartbeatInterval = setInterval(() => {
      this.sendHeartbeat();
    }, 30000);

    // 첫 하트비트 즉시 전송
    this.sendHeartbeat();
  }

  /**
   * 하트비트 전송 중지
   */
  private stopHeartbeat(): void {
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
      this.heartbeatInterval = null;
    }
    if (this.heartbeatTimeout) {
      clearTimeout(this.heartbeatTimeout);
      this.heartbeatTimeout = null;
    }
  }

  /**
   * 하트비트 메시지 전송
   */
  private sendHeartbeat(): void {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
      console.warn('⚠️ WebSocket이 연결되지 않았습니다.');
      return;
    }

    const heartbeat: HeartbeatMessage = {
      type: 'heartbeat',
      timestamp: new Date().toISOString(),
    };

    try {
      this.ws.send(JSON.stringify(heartbeat));
      console.log('💓 하트비트 전송:', heartbeat.timestamp);
    } catch (error) {
      console.error('❌ 하트비트 전송 실패:', error);
    }
  }

  /**
   * 하트비트 타임아웃 리셋
   * - 60초 동안 하트비트 ACK가 없으면 연결 종료
   */
  private resetHeartbeatTimeout(): void {
    if (this.heartbeatTimeout) {
      clearTimeout(this.heartbeatTimeout);
    }

    // 60초 타임아웃
    this.heartbeatTimeout = setTimeout(() => {
      console.error('❌ 하트비트 타임아웃 - 연결 종료');
      this.disconnect();
    }, 60000);
  }

  /**
   * WebSocket 연결 종료
   */
  disconnect(): void {
    console.log('🔌 WebSocket 연결 종료 요청');

    this.stopHeartbeat();
    this.reconnectAttempts = this.maxReconnectAttempts; // 재연결 방지

    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }

    this.state = WebSocketState.DISCONNECTED;
  }

  /**
   * 연결 상태 조회
   */
  getState(): WebSocketState {
    return this.state;
  }

  /**
   * 연결 여부 확인
   */
  isConnected(): boolean {
    return this.state === WebSocketState.CONNECTED &&
      this.ws !== null &&
      this.ws.readyState === WebSocket.OPEN;
  }
}

/**
 * 싱글톤 인스턴스
 */
let wsManagerInstance: WebSocketHeartbeatManager | null = null;

/**
 * WebSocket 하트비트 매니저 싱글톤 반환
 */
export function getWebSocketManager(): WebSocketHeartbeatManager {
  if (!wsManagerInstance) {
    wsManagerInstance = new WebSocketHeartbeatManager();
  }
  return wsManagerInstance;
}