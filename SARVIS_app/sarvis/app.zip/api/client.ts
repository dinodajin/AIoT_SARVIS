import axios, { AxiosError, InternalAxiosRequestConfig, AxiosResponse } from 'axios';
import { API_CONFIG } from '../constants/config';
import AsyncStorage from '@react-native-async-storage/async-storage';

// 디버그 로깅 함수
const logRequest = (config: InternalAxiosRequestConfig) => {
  console.log('[API REQUEST]', {
    method: config.method?.toUpperCase(),
    url: `${config.baseURL}${config.url}`,
    data: config.data,
    timeout: config.timeout,
  });
};

const logResponse = (response: AxiosResponse) => {
  console.log('[API RESPONSE]', {
    status: response.status,
    url: response.config.url,
    data: response.data,
  });
};

const logError = (error: AxiosError) => {
  console.error('[API ERROR]', {
    message: error.message,
    code: error.code,
    url: error.config?.url,
    status: error.response?.status,
    responseData: error.response?.data,
  });
};

// EC2 server client - signup, login, profile APIs
const ec2Client = axios.create({
  baseURL: API_CONFIG.EC2_URL,
  timeout: API_CONFIG.TIMEOUT,
  headers: {
    'Content-Type': 'application/json',
  },
});

// EC2 요청 인터셉터 - JWT 토큰 및 로깅
ec2Client.interceptors.request.use(
  async (config) => {
    logRequest(config);
    const token = await AsyncStorage.getItem('@sarvis_access_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    logError(error);
    return Promise.reject(error);
  }
);

// EC2 응답 인터셉터 - 로깅
ec2Client.interceptors.response.use(
  (response) => {
    logResponse(response);
    return response;
  },
  (error) => {
    logError(error);
    return Promise.reject(error);
  }
);

// Jetson server client - face, voice processing
const jetsonClient = axios.create({
  baseURL: API_CONFIG.JETSON_URL,
  timeout: API_CONFIG.TIMEOUT,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Jetson 요청 인터셉터 - 로깅
jetsonClient.interceptors.request.use(
  (config) => {
    logRequest(config);
    return config;
  },
  (error) => {
    logError(error);
    return Promise.reject(error);
  }
);

// Jetson 응답 인터셉터 - 로깅
jetsonClient.interceptors.response.use(
  (response) => {
    logResponse(response);
    return response;
  },
  (error) => {
    logError(error);
    return Promise.reject(error);
  }
);

export { ec2Client, jetsonClient };
