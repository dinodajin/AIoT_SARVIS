// api/control.ts

import { ec2Client } from './client';
import {
    ControlEnterResponse,
    ControlButtonResponse,
    ButtonCommandResponse,
    ButtonDirection,
} from './types';

/**
 * 제어 명령 API
 */
export const controlAPI = {
    /**
     * 제어 화면 진입
     * @param connectionUuid WebSocket 연결 UUID
     */
    async enter(connectionUuid: string): Promise<ControlEnterResponse> {
        const response = await ec2Client.post<ControlEnterResponse>(
            '/api/control/enter/',
            { connection_uuid: connectionUuid }
        );
        return response.data;
    },

    /**
     * 버튼 명령 전송 (기존)
     * @param connectionUuid WebSocket 연결 UUID
     * @param buttonType 버튼 타입 (MOVE, TILT, ROTATE 등)
     * @param buttonLabel 버튼 라벨 (forward, backward, left, right 등)
     */
    async sendButton(
        connectionUuid: string,
        buttonType: string,
        buttonLabel: string
    ): Promise<ControlButtonResponse> {
        const response = await ec2Client.post<ControlButtonResponse>(
            '/api/control/button/',
            {
                connection_uuid: connectionUuid,
                button_type: buttonType,
                button_label: buttonLabel,
            }
        );
        return response.data;
    },

    /**
     * 로봇팔 버튼 커맨드 전송 (새로운 API)
     * @param sessionId 세션 ID (숫자형)
     * @param command 버튼 명령 (UP, DOWN, LEFT, RIGHT, FAR, NEAR, YAW_RIGHT, YAW_LEFT, PITCH_UP, PITCH_DOWN)
     */
    async sendButtonCommand(
        sessionId: number,
        command: ButtonDirection
    ): Promise<ButtonCommandResponse> {
        const response = await ec2Client.post<ButtonCommandResponse>(
            '/api/control/button/',
            {
                session_id: sessionId,
                command: command,
            }
        );
        return response.data;
    },
};
